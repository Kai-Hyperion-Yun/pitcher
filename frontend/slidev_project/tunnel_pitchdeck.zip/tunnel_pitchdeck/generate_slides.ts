import { GoogleGenerativeAI } from '@google/generative-ai'
import axios from 'axios'
import fs from 'fs/promises'
import path from 'path'
import yaml from 'js-yaml'
import { fileURLToPath } from 'url'
import { loadConfig, initializeAI } from './config.js'
import { ScreenplayData, SlideConfig, Comparable } from './models.js'
import { slideConfigs } from './slideConfigs.js'
import { dirname } from 'path'


// Fix for __dirname in ES modules
const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

// Load configuration
const configFilePath = path.join(__dirname, 'config.yaml');
const fileContents = await fs.readFile(configFilePath, 'utf-8');
const config = yaml.load(fileContents) as { google_api_key: string };

// Initialize AI
const genAI = initializeAI(config.google_api_key);
const model = genAI.getGenerativeModel({ model: 'gemini-pro' });


// // This is to fetch Comparables from TMDB via backend
// async function fetchComparableImages(titles: string[]): Promise<Comparable[]> {
//   try {
//     const response = await axios.post('http://localhost:3030/fetch-comp-images', {
//       comps: titles
//     });

//     const imagePaths = response.data;
//     return titles.map(title => ({
//       title,
//       imagePath: imagePaths[title] || '', // use the base64 data url
//       boxOffice: fetchComparableImages.find(comp => comp.title === title)?.boxOffice || 'N/A'
//     }));
//   } catch (error) {
//     console.error('Error fetching comparable images:', error);
//     return [];
//   }
// }



// This is new function to fetch all the comparable details from TMDB via backend
async function fetchComparablesDetails(titles: string[]): Promise<Comparable[]> {
  try {
    const response = await axios.post('http://localhost:3030/fetch-comparable-details', {
      titles
    });

    const details = response.data;
    return Object.keys(details).map(title => ({
      title: details[title].original_title,
      base64Image: details[title].image, // BAse64 image data
      boxOffice: `$${(details[title].revenue.revenue / 1e6).toFixed(1)}M` // convert revenue to a string with 'M' for millions
    }));
  } catch (error) {
    console.error('Error fetching comparable details:', error);
    return [];
  }
}


async function generateImage(prompt: string) {
  try {
    const response = await axios.post('http://localhost:3030/generate-image', {
      prompt,
      model_name: 'flux-schnell'
    });
    return response.data.image;
  } catch (error) {
    console.error('Error generating image:', error);
    return null;
  }
}



 
class SlideGenerator {
  private screenplayData: ScreenplayData


  constructor(screenplayData: ScreenplayData) {
    this.screenplayData = screenplayData
  }


  async generateSlide(config: SlideConfig): Promise<string> {
    // Directly format the prompt without using AI
    const formattedContent = this.formatPrompt(config.prompt)
    return formattedContent.trim()
  }


  private formatPrompt(prompt: string): string {
    return prompt.replace(/{{(\w+)}}/g, (match, key) => {
      switch (key) {
        case 'title_data':
          return JSON.stringify({

            title: "Bad Ass Girls",
            writer: this.screenplayData?.writer || 'Unknown Writer',
            backgroundImage: "https://cover.sli.dev"

          }, null, 2)
        

        case 'logline_data':
          return JSON.stringify({
            logline: this.screenplayData?.coverage_report?.logline || 'Logline not available',
            genre: this.screenplayData?.coverage_report?.production_scheme?.genre || 'Genre not specified',
            image: "/logline_images/logline_bad-ass-girls.jpeg"
          }, null, 2)
        

        case 'miranda_kent_details':
          const mirandaData = this.screenplayData.coverage_report.character_breakdowns
            .find(char => char.name === "Miranda Kent")
          
          if (!mirandaData) {
            console.warn('Miranda Kent character data not found')
            return JSON.stringify({
              name: 'Miranda Kent',
              type: 'lead',
              comps: [],
              gender: '',
              age_range: '',
              ethnicity: '',
              description: 'Character data not found'
            }, null, 2)
          }


          return JSON.stringify({
            name: mirandaData.name,
            type: mirandaData.type,
            comps: mirandaData.comps,
            gender: mirandaData.gender,
            age_range: mirandaData.age_range,
            ethnicity: mirandaData.ethnicity,
            description: mirandaData.description
          }, null, 2)
        

        case 'lead_characters':
          const leadCharacters = this.screenplayData?.coverage_report?.character_breakdowns
            ?.filter(char => char.type === 'lead') || []
          
          return JSON.stringify(leadCharacters, null, 2)
        
        default:
          return match
      }
    })
  }

  async generateAllSlides(): Promise<string> {
    const slides: string[] = [];

    // Fetch comparable details
    const comparableTitles = ["Kill Bill", "Faster Pussycat! Kill! Kill!", "Sin City", "Machete", "Bitch Slap"];
    const updatedComparables = await fetchComparablesDetails(comparableTitles);
    // console.log('Updated comparables:', updatedComparables);

    // update slideConfigs with the new fetched comparables
    const updatedSlideConfigs = slideConfigs.map(config => {
      if (config.name === 'comparables') {
        return {
          ...config,
          prompt: config.prompt.replace(
            /{{comparables}}/,
            JSON.stringify(updatedComparables, null, 2) // Ensure JSON is properly formatted
          )
        };
      }
      return config;
    });
    // console.log('Updated slide configs:', updatedSlideConfigs); 
    for (const config of updatedSlideConfigs) {
      try {
        const slideContent = await this.generateSlide(config);

        if (slideContent) {
          slides.push(slideContent.trim())
          console.log(`✓ Generated ${config.name} slide`)
        }
      } catch (error) {
        console.error(`× Failed to generate ${config.name} slide:`, error)
      }
    }

    // Join slides with a single separator
    return slides.join('\n')
  }
}

// async function fetchAndSaveImages(comps: string[]) {
//   try {
//     const response = await axios.post('http://localhost:3030/fetch-comp-images', { comps });
//     const imageUrls = response.data;
//     for (const [comp, url] of Object.entries(imageUrls)) {
//       downloadImage(url, comp);
//     }
//   } catch (error) {
//     console.error('Error fetching images frontend from TMDB:', error);
//   }
// }

// function downloadImage(url: string, filename: string) {
//   axios({
//     url,
//     method: 'GET',
//     responseType: 'blob',
//   }).then((response) => {
//     const url = window.URL.createObjectURL(new Blob([response.data]));
//     const link = document.createElement('a');
//     link.href = url;
//     link.setAttribute('download', )

async function main() {
  try {
    // Read screenplay JSON
    const jsonPath = path.join(__dirname, 'bad-ass-girls.json')
    const screenplayData = JSON.parse(
      await fs.readFile(jsonPath, 'utf-8')
    ) as ScreenplayData

    // Generate slides
    const generator = new SlideGenerator(screenplayData);
    const slidesContent = await generator.generateAllSlides();
    console.log('Slides content:', slidesContent);
    // Save to slides.md
    const outputPath = path.join(__dirname, 'slides.md');
    console.log('Output path:', outputPath);
    try {
      await fs.writeFile(outputPath, slidesContent);
      console.log('Slides generated successfully!');
    } catch (writeError) {
      console.error('Error writing slides.md:', writeError);
    }

  } catch (error) {
    console.error('Error:', error)
  }


  // This is test to generate an image
  // try {
  //   const image = await generateImage('A beautiful landscape with a river and mountains');
  //   console.log('Generated Image:', image);
  // } catch (error) {
  //   console.error('Error:', error);
  // }


  // This is test to fetch images from TMDB

}

main() 