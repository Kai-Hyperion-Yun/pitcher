export interface SlideConfig {
    name: string // name of the lside (title, logline ,etc)
    prompt: string // the proompt to send to gemini
}
  
export interface CharacterBreakdown {
    name: string
    type: string
    description: string
    age_range: string
    comps: string[]
    gender: string
    ethnicity: string
}

export interface Comparable {
    title: string
    base64Image: string
    boxOffice: string
}

export interface ScreenplayData {
    writer: string
    coverage_report: {
        logline: string
        production_scheme: {
            genre: string
        }
        character_breakdowns: CharacterBreakdown[]
        analysis: {
            comps: string[]
        }
    }
}
  
