<script setup>
defineProps({
  frames: {
    type: Array,
    required: true,
    default: () => [],
    // Each frame should have: { image, description, reference }
  }
})
</script>

<template>
  <div class="grid grid-cols-2 gap-6 w-full">
    <div 
      v-for="frame in frames" 
      :key="frame.description"
      class="relative"
    >
      <img 
        :src="frame.image" 
        class="w-full h-64 object-cover rounded-lg shadow-lg mb-2"
        :alt="frame.description"
      />
      <p class="text-lg font-semibold">{{ frame.description }}</p>
      <p class="text-sm text-gray-500">Reference: {{ frame.reference }}</p>
    </div>
  </div>
</template> 