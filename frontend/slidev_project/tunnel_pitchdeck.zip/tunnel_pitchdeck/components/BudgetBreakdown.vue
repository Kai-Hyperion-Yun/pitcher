<script setup>
defineProps({
  budgetData: {
    type: Object,
    required: true,
    default: () => ({
      totalBudget: '',
      breakdowns: [],
      notes: []
    })
  }
})
</script>

<template>
  <div class="p-1">
    <!-- Total Budget Header -->
    <div class="text-center mb-3">
      <h3 class="font-bold text-primary">Total Budget: {{ budgetData.totalBudget }}</h3>
    </div>

    <!-- Budget Breakdown Grid -->
    <div class="grid grid-cols-2 gap-2 mb-5">
      <div 
        v-for="breakdown in budgetData.breakdowns" 
        :key="breakdown.category"
        class="bg-gray-700 rounded-lg p-1.5"
      >
        <div class="flex justify-between items-center mb-1">
          <h3 class="text-xl font-semibold">{{ breakdown.category }}</h3>
          <div class="text-right">
            <div class="text-2xl font-bold">{{ breakdown.amount }}</div>
            <div class="text-sm text-gray-400">{{ breakdown.percentage }}%</div>
          </div>
        </div>
        <ul class="text-sm space-y-0.5">
          <li 
            v-for="item in breakdown.items" 
            :key="item"
            class="flex items-center"
          >
            <span class="w-2 h-2 bg-primary rounded-full mr-2"></span>
            {{ item }}
          </li>
        </ul>
      </div>
    </div>

    <!-- Notes Section -->
    <div class="bg-gray-50 rounded-lg p-4">
      <h3 class="text-lg font-semibold mb-3">Notes</h3>
      <ul class="space-y-2">
        <li 
          v-for="note in budgetData.notes" 
          :key="note"
          class="flex items-start"
        >
          <span class="text-primary mr-2">•</span>
          {{ note }}
        </li>
      </ul>
    </div>
  </div>
</template>

<style scoped>
.text-primary {
  color: white;
}
.bg-primary {
  background-color: #3B82F6;
}
</style> 