<template>
  <div class="p-8  text-white text-center">
    <h1 class="text-4xl font-bold mb-4">Thank You!</h1>
    <p class="text-lg mb-8">We appreciate your time and consideration.</p>
    <div class="text-lg">
      <p>Contact Us:</p>
      <p>Email: <a href="mailto:contact@filmproduction.com" class="text-blue-400">contact@filmproduction.com</a></p>
      <p>Phone: <a href="tel:+1234567890" class="text-blue-400">+1 (234) 567-890</a></p>
    </div>
  </div>
</template>

<script setup>
// No props needed for this simple component
</script> 