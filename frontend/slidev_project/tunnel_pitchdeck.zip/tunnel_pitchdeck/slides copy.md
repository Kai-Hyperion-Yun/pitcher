---
layout: default
class: text-center
aspectRatio: 16/9
---

<script setup>
import TitleSlide from './components/TitleSlide.vue'

const titleData = {
  "title": "Bad Ass Girls",
  "writer": "Tom Malloy",
  "backgroundImage": "https://cover.sli.dev"
}
</script>

<TitleSlide :title-data="titleData" />
---
layout: default
---

<script setup>
import LoglineSlide from './components/LoglineSlide.vue'

const loglineData = {
  "logline": "When a group of wronged women, each with unique fighting skills and a vendetta against the men who hurt them, unite under the guidance of a mysterious news anchor, they unleash a wave of violent justice across Los Angeles, targeting corrupt criminals and powerful figures, all while evading a determined police force.",
  "genre": "This script blends several genres, primarily action, crime, and neo-noir, with elements of dark comedy and revenge thriller. There is a strong emphasis on stylized violence and a pulpy, comic-book feel. The story follows multiple female characters who each have their own brand of vigilante justice. The dialogue is often sarcastic, witty, and sometimes over-the-top, leaning into the B-movie aesthetic.\n\n",
  "image": "/logline_images/logline_bad-ass-girls.jpeg"
}
</script>

<LoglineSlide :logline-data="loglineData" />
---
layout: default
class: text-center
---

# Comparable Films

<script setup>
import ComparablesGrid from './components/ComparablesGrid.vue'
const comparables = [{"title":"Kill Bill","imagePath":"/comp_posters/Kill Bill.jpg","boxOffice":"$180M"},{"title":"Faster Pussycat! Kill! Kill!","imagePath":"/comp_posters/Faster Pussycat! Kill! Kill!.jpg","boxOffice":"$230M"},{"title":"Sin City","imagePath":"/comp_posters/Sin City.jpg","boxOffice":"$158M"},{"title":"Machete","imagePath":"/comp_posters/Machete.jpg","boxOffice":"$100M"},{"title":"Bitch Slap","imagePath":"/comp_posters/Bitch Slap.jpg","boxOffice":"$100M"}]
</script>

<ComparablesGrid :comparables="comparables" />
---
layout: default
---

# Cast & Crew

<script setup>
import CastGrid from './components/CastGrid.vue'
const cast = [
{ name: "Lead Actor", role: "Director" },
{ name: "Apple John", role: "Producer" },
{ name: "Banana Jane", role: "Writer" },
{ name: "Cherry Carrol", role: "Editor"}
]
</script>

<CastGrid :cast="cast" />
---
layout: default
---

<script setup>
import LeadCharacterDetail from './components/LeadCharacterDetail.vue'

const character = {
  "name": "Miranda Kent",
  "type": "lead",
  "comps": [
    "Amy Adams",
    "Julianne Moore",
    "Naomi Watts"
  ],
  "gender": "female",
  "age_range": "late 30s",
  "ethnicity": "white",
  "description": "A driven and ambitious news anchor, secretly the leader of a vigilante group called 'Scarlet Fever'. She is intelligent and capable, but also ruthless when necessary."
}
</script>

<LeadCharacterDetail :character="character" />
---
layout: default
---

<script setup>
import LeadCharactersGrid from './components/LeadCharactersGrid.vue'
const characters = [
  {
    "name": "Miranda Kent",
    "type": "lead",
    "comps": [
      "Amy Adams",
      "Julianne Moore",
      "Naomi Watts"
    ],
    "gender": "female",
    "age_range": "late 30s",
    "ethnicity": "white",
    "description": "A driven and ambitious news anchor, secretly the leader of a vigilante group called 'Scarlet Fever'. She is intelligent and capable, but also ruthless when necessary."
  },
  {
    "name": "Ruby Chopper",
    "type": "lead",
    "comps": [
      "Kristen Stewart",
      "Rooney Mara",
      "Abbey Lee"
    ],
    "gender": "female",
    "age_range": "late 20s",
    "ethnicity": "white",
    "description": "A bad-ass biker with a dark past. She seeks revenge on her childhood abuser. She is tough and fearless, with a strong sense of justice."
  },
  {
    "name": "Pleather",
    "type": "lead",
    "comps": [
      "Anya Taylor-Joy",
      "Elle Fanning",
      "Florence Pugh"
    ],
    "gender": "female",
    "age_range": "early 20s",
    "ethnicity": "white",
    "description": "A seemingly meek pet store clerk with a hidden side. She's a vegan vigilante who targets animal abusers. She is resourceful and skilled in combat."
  },
  {
    "name": "Ink",
    "type": "lead",
    "comps": [
      "Lashana Lynch",
      "Kiki Layne",
      "Teyonah Parris"
    ],
    "gender": "female",
    "age_range": "late 20s",
    "ethnicity": "African American",
    "description": "A skilled tattoo artist with a talent for combat. She targets men who abuse women. She's fiercely independent and loyal to her cause."
  }
]
</script>

<LeadCharactersGrid :characters="characters" />
---
layout: default
---

# Visual Style

<script setup>
import StyleFrameGrid from './components/StyleFrameGrid.vue'
const frames = [
  {
    image: '/style_frames/frame1.jpg',
    description: 'Night scene with neon lighting',
    reference: 'Blade Runner 2049'
  },
  {
    image: '/style_frames/frame2.jpg',
    description: 'High contrast action sequence',
    reference: 'John Wick'
  },
  {
    image: '/style_frames/frame3.jpg',
    description: 'Intimate character moment',
    reference: 'Lost in Translation'
  },
  {
    image: '/style_frames/frame4.jpg',
    description: 'Urban landscape',
    reference: 'Drive'
  }
]
</script>

<StyleFrameGrid :frames="frames" />
---
layout: default
---

# Look Book - Visual Tone

<script setup>
import LookBook from './components/LookBook.vue'
const section = {
  title: 'Cinematography & Lighting',
  description: 'Natural lighting with dramatic contrast, emphasizing the raw emotional moments',
  colorPalette: ['#2C3E50', '#E74C3C', '#ECF0F1', '#2980B9'],
  images: [
    {
      url: '/lookbook/lighting1.jpg',
      caption: 'Natural light through windows'
    },
    {
      url: '/lookbook/lighting2.jpg',
      caption: 'High contrast night scenes'
    },
    {
      url: '/lookbook/lighting3.jpg',
      caption: 'Intimate close-ups'
    }
  ]
}
</script>

<LookBook :section="section" />
---
layout: default
---

# Budget Breakdown

<script setup>
import BudgetBreakdown from './components/BudgetBreakdown.vue'

const budgetData = {
  totalBudget: "4.5M",
  breakdowns: [
    {
      category: "Above the Line",
      amount: "1.2M",
      percentage: 27,
      items: [
        "Cast",
        "Director",
        "Producers",
        "Writers"
      ]
    },
    {
      category: "Production",
      amount: "2.1M",
      percentage: 47,
      items: [
        "Crew",
        "Equipment",
        "Locations",
        "Action Sequences",
        "Special Effects"
      ]
    },
    {
      category: "Post-Production",
      amount: "800K",
      percentage: 18,
      items: [
        "Editing",
        "Sound Design",
        "Visual Effects",
        "Color Grading",
        "Music"
      ]
    },
    {
      category: "Other",
      amount: "400K",
      percentage: 8,
      items: [
        "Insurance",
        "Legal",
        "Marketing",
        "Contingency"
      ]
    }
  ],
  notes: [
    "Tax incentives available in Los Angeles",
    "Potential co-production opportunities",
    "Action sequences budgeted for practical effects"
  ]
}
</script>

<BudgetBreakdown :budget-data="budgetData" />
---
layout: default
---

<script setup>
import ProductionTimeline from './components/ProductionTimeline.vue'

const timelineData = [
  { phase: 'Pre-Production', start: 'Jan 2024', end: 'Mar 2024' },
  { phase: 'Production', start: 'Apr 2024', end: 'Jun 2024' },
  { phase: 'Post-Production', start: 'Jul 2024', end: 'Sep 2024' },
  { phase: 'Release', start: 'Oct 2024', end: 'Dec 2024' }
]
</script>

<ProductionTimeline :timeline-data="timelineData" />
---
layout: default
---

<script setup>
import ContactSlide from './components/ContactSlide.vue'
</script>

<ContactSlide />