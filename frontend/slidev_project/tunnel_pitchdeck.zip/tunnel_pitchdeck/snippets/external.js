/* eslint-disable no-console */
// #region snippet
// Inside ./snippets/external.ts
export function emptyArray(length) {
    return Array.from({ length });
}
// #endregion snippet
export function sayHello() {
    console.log('Hello from snippets/external.ts');
}
